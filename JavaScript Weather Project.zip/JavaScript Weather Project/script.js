let weatherApikey = "8bca890e7b3cefd5ee1cd30ffa5229ba";
let baseEndPoint =
  "https://api.openweathermap.org/data/2.5/weather?appid=" +
  weatherApikey +
  "&units=metric";

let forecastEndpoint =
  "https://api.openweathermap.org/data/2.5/forecast?appid=" +
  weatherApikey +
  "&units=metric";

let geocodingBaseEndPoint =
  "http://api.openweathermap.org/geo/1.0/direct?&limit=5&appid=" +
  weatherApikey +
  "&q=";

let getCityName = document.querySelector("#search");
let city = document.querySelector(".weather_city");
let day = document.querySelector(".weather_day");
let humidity = document.querySelector(".weather_indicator--humidity > .value");
let wind = document.querySelector(".weather_indicator--wind > .value");
let pressure = document.querySelector(".weather_indicator--pressure > .value");
let temperature = document.querySelector(".weather_temperature > .value");
let image = document.querySelector(".weather_image");
let forcastBlock = document.querySelector(".weather_forecast");
let dataList = document.querySelector("#suggestions");
let weatherImages = [
  {
    url: "images/broken-clouds.png",
    ids: [803, 804],
  },
  {
    url: "images/clear-sky.png",
    ids: [800],
  },
  {
    url: "images/few-clouds.png",
    ids: [801],
  },
  {
    url: "images/mist.png",
    ids: [701, 711, 721, 731, 741, 751, 761, 762, 771, 781],
  },
  {
    url: "images/rain.png",
    ids: [500, 501, 502, 503, 504],
  },
  {
    url: "images/scattered-clouds.png",
    ids: [802],
  },
  {
    url: "images/shower-rain.png",
    ids: [520, 521, 522, 531, 300, 301, 302, 310, 311, 312, 313, 314, 315],
  },
  {
    url: "images/snow.png",
    ids: [511, 600, 601, 602, 611, 612, 613, 615, 616, 620, 621, 622],
  },
  {
    url: "images/thunderstorm.png",
    ids: [200, 201, 202, 210, 211, 212, 221, 230, 231, 232],
  },
];

let updateForcast = (daily) => {
  forcastBlock.innerHTML = "";
  let forcastItem = "";
  daily.forEach((day) => {
    let iconUrl =
      "http://openweathermap.org/img/wn/" + day.weather[0].icon + "@2x.png";
    temperatureForcast =
      day.main.temp > 0
        ? "+" + Math.round(day.main.temp)
        : Math.round(day.main.temp);
    let dayName = dayOfweek(day.dt * 1000);
    forcastItem += `	<article class="weather_forecast_item">
					<img src="${iconUrl}" alt="Clear sky" class="weather_forecast_icon">
					<h3 class="weather_forecast_day">${dayName}</h3>
					<p class="weather_forecast_temperature">
						<span class="value">${temperatureForcast}</span>
						&deg;C</p>
				</article>`;
  });

  forcastBlock.innerHTML = forcastItem;
};

let getWeatherBycityName = async (city) => {
  let endpoint = baseEndPoint + "&q=" + city;
  let response = await fetch(endpoint);
  let weather = await response.json();
  return weather;
};

let dayOfweek = (dt) => {
  let today = new Date(dt).toLocaleDateString("en-En", { weekday: "long" });
  return today;
};

let getWeatherforecastBycityID = async (id) => {
  let endpoint = forecastEndpoint + "&id=" + id;
  let response = await fetch(endpoint);
  let weatherForecast = await response.json();
  let daily = [];

  weatherForecast.list.forEach((day) => {
    let date_txt = day.dt_txt;
    date_txt = date_txt.replace(" ", "T");
    let date = new Date(date_txt);
    let hours = date.getHours();
    if (hours === 12) {
      daily.push(day);
    }
  });
  return daily;
};

let updateCurrentWeather = (data) => {
  city.innerText = data.name;
  day.innerText = new Date().toLocaleDateString("en-En", { weekday: "long" });
  humidity.innerText = data.main.humidity;
  pressure.innerText = data.main.pressure;
  let windDirection;
  let deg = data.wind.deg;
  if (deg > 45 && deg <= 135) {
    windDirection = "East";
  } else if (deg > 135 && deg <= 225) {
    windDirection = "South";
  } else if (deg > 225 && deg <= 315) {
    windDirection = "West";
  } else {
    windDirection = "North";
  }
  wind.innerText = windDirection + " ," + data.wind.speed;
  temperature.innerText =
    data.main.temp > 0
      ? "+" + Math.round(data.main.temp)
      : Math.round(data.main.temp);
  let imgID = data.weather[0].id;
  weatherImages.forEach((obj) => {
    if (obj.ids.indexOf(imgID) != -1) {
      image.src = obj.url;
    }
  });
};

let weatherForCity = async (city) => {
  let weather = await getWeatherBycityName(city);
  if (weather.cod === "404") {
    Swal.fire({ icon: "error", title: "OOPs.....", text: "Invalid City Name" });
    return;
  }
  updateCurrentWeather(weather);
  let cityID = weather.id;
  let forcast = await getWeatherforecastBycityID(cityID);
  updateForcast(forcast);
};

getCityName.addEventListener("keydown", async (e) => {
  if (e.keyCode === 13) {
    weatherForCity(getCityName.value);
  }
});
getCityName.addEventListener("input", async (e) => {
  if (getCityName.value.length <= 2) {
    return;
  }
  let endpoint = geocodingBaseEndPoint + getCityName.value;
  let result = await fetch(endpoint);
  result = await result.json();
  dataList.innerHTML = "";
  result.forEach((city) => {
    let option = document.createElement("option");
    option.value = `${city.name}${city.state ? "," + city.state : ""},${
      city.country
    }`;
    dataList.appendChild(option);
    // console.log(`${city.name},${city.state},${city.country}`);
  });
});
